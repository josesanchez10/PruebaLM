package main

import (
	"Proyecto/data/impl"
	"Proyecto/data/request"
	"testing"
)

func Test(t *testing.T) {
	deco := request.TraductorRequest{"murcielago", "", false}
	encMurcielago := impl.EncodeMurcielago{}
	var res = deco.Encode(encMurcielago)
	if res.Text != "0123456789" {
		t.Errorf("No hace merge la respuesta con la prueba unitaria")
	}
}
