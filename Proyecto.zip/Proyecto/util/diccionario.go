package util

func DecodeMurcielago(val string) string {
	if val == "0" {
		return "m"
	} else if val == "1"{
		return "u"
	} else if val == "2"{
		return "r"
	} else if val == "3"{
		return "c"
	} else if val == "4"{
		return "i"
	} else if val == "5"{
		return "e"
	} else if val == "6"{
		return "l"
	} else if val == "7"{
		return "a"
	} else if val == "8"{
		return "g"
	} else if val == "9"{
		return "o"
	} else {
		return val
	}
}

func EncodeMurcielago(val string) string {
	if val == "M" || val == "m" {
		return "0"
	} else if val == "U" || val == "u" {
		return "1"
	} else if val == "R" || val == "r" {
		return "2"
	} else if val == "C" || val == "c" {
		return "3"
	} else if val == "I" || val == "i" {
		return "4"
	} else if val == "E" || val == "e" {
		return "5"
	} else if val == "L" || val == "l" {
		return "6"
	} else if val == "A" || val == "a" {
		return "7"
	} else if val == "G" || val == "g" {
		return "8"
	} else if val == "O" || val == "o" {
		return "9"
	} else {
		return val
	}
}
