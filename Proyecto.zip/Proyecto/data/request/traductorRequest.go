package request

import (
	"Proyecto/data/response"
)

/*
Definicion de la estructura
*/
type TraductorRequest struct {
	Text      string
	Tipo    string
	DecodeVal bool
}

/*
Inicio de defincion interfaces
*/
type Decode interface {
	Decode(val string) response.TraductorResponse
}

type Encode interface {
	Encode(val string) response.TraductorResponse
}

/*
Inicio de las funciones para definir contratos e invocar las funciones de implementacion
*/
func (r *TraductorRequest) Decode(i Decode) response.TraductorResponse {
	return i.Decode(r.Text)
}

func (r *TraductorRequest) Encode(i Encode) response.TraductorResponse {
	return i.Encode(r.Text)
}
