package impl

import (
	"Proyecto/data/response"
	"Proyecto/util"
	"strings"
)

type EncodeMurcielago struct{}

//Creamos los metodos paraimplementar intefaz y encriptar los datos
func (murcielago EncodeMurcielago) Encode(val string) response.TraductorResponse {

	s := strings.Split(val, "")
	var res string
	for i := 0; i < len(s); i++ {
		res += util.EncodeMurcielago(s[i])
	}

	return response.TraductorResponse{res}
}
