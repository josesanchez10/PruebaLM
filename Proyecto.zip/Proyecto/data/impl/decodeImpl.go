package impl

import (
	"Proyecto/data/response"
	"Proyecto/util"
	"strings"
)

type DecodeMurcielago struct{}

//Creamos los metodos paradesencriptar datos
func (murcielago DecodeMurcielago) Decode(val string) response.TraductorResponse {

	s := strings.Split(val, "")
	var res string
	for i := 0; i < len(s); i++ {
		res += util.DecodeMurcielago(s[i])
	}

	return response.TraductorResponse{res}
}
