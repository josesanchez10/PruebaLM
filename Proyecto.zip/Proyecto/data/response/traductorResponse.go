package response

type TraductorResponse struct {
	Text string
}
