package main

import (
	//"Proyecto/util"
	"fmt"
	"Proyecto/data/impl"
	"Proyecto/data/request"
)

func main() {

	//fmt.PrintlnPeenter your name.")
	//name string
	//Scanln(&name)
	//Printf("Hi, %s! I'm Go!", name)*/

	/*arreglo := [] it {, 2,}
	var matriz [3][2]int
	for i := 0; i < len(arreo); i++ {
		t.Println(arreglo[i])
	}
	for i := 0; i < 3; i++ {
		for j := 0; j < 2; j+{
			triz[i][j] = i + j

	}
	mt.Println(matriz)

	*/

	/*
					result := funcionDe
				fmt.Println(resul

		fmt.Println("Respuesta"
				fmt.Println(util.EncryptMurcielago("a"
	*/

	deco := request.TraductorRequest{"murcielago", "", false}


	fmt.Println("Respuesta MURCIELAGO ENCODE encriptar")
	fmt.Println(deco.Text)
	encMurcielago := impl.EncodeMurcielago{}
	var respuesta1 = deco.Encode(encMurcielago);
	fmt.Println(respuesta1.Text)

	fmt.Println("Respuesta MURCIELAGO DECO desencriptar")
	fmt.Println(deco.Text)
	codMurcielago := impl.DecodeMurcielago{}
	var respuesta = deco.Decode(codMurcielago);
	fmt.Println(respuesta.Text)
	
	
	
}

/*
func funcnDe(x int) int {
	:= x * 2
	rurn y
}
*/
