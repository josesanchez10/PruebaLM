package impl

import (
	"fmt"
	//"strings"
)

/*
Definicion de la estructura
*/
type PassNivel1 struct{}
type PassNivel2 struct{}
type PassNivel3 struct{}

//Implementacion de interfaz para la validacion de contraseñas
func (pass1 PassNivel1) ValidatePassword(pass string) bool {
	fmt.Println("** Llego validacion de Password Nivel 1 ** ")
	var res = true
	if len(pass) <= 8 {
		fmt.Println("   >>> Contraseña NO cumple longitud mayor a 8 caracteres")
		res = false
	} else {
		fmt.Println("   >>> Contraseña cumple longitud mayor a 8 caracteres")
	}
	return res
}

func (pass2 PassNivel2) ValidatePassword(pass string) bool {
	var res = true
	fmt.Println("** Llego validacion de Password Nivel 2 ** ")
	fmt.Println(pass)
	return res
}

func (pass3 PassNivel3) ValidatePassword(pass string) bool {
	var res = true
	fmt.Println("** Llego validacion de Password Nivel 3 ** ")
	fmt.Println(pass)
	return res
}
