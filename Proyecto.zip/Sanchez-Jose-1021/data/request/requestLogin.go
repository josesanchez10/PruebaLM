package request

/*
Definicion de la estructura
*/
type RequestLogin struct {
	Rol      string
	Password string
}

/*
Defincion interfaces
*/
type Login interface {
	ValidatePassword(pass string) bool
}

/*
funcion para definir contratos e invocar las funcion de implementacion
*/
func (r *RequestLogin) Validate(i Login) bool {
	return i.ValidatePassword(r.Password)
}
