package main

import (
	"fmt"
	"Sanchez-Jose-1021/data/impl"
	"Sanchez-Jose-1021/data/request"
)

func main() {
	
	req := request.RequestLogin{"COORDINADOR", "pass"}
	pass1 := impl.PassNivel1{}
	pass2 := impl.PassNivel2{}
	pass3 := impl.PassNivel3{}
	
	if req.Rol == "ANALISTA" {
		req.Validate(pass1)
		fmt.Println("Rol de analista")
	} else if req.Rol == "COORDINADOR" {
		req.Validate(pass1)
		req.Validate(pass2)
		fmt.Println("Rol de COORDINADOR")
	}else {
		req.Validate(pass1)
		req.Validate(pass2)
		req.Validate(pass3)
		fmt.Println("Rol de GERENTE")
	}
}
