package main

import (
	"Sanchez-Jose-1021/data/impl"
	"Sanchez-Jose-1021/data/request"
	"testing"
)

func Test1Exito(t *testing.T) {
	req := request.RequestLogin{"COORDINADOR", "password1"}
	pass1 := impl.PassNivel1{}
	var res = req.Validate(pass1)
	if res != true {
		t.Errorf("No hace merge la respuesta con la prueba unitaria")
	}
}

func Test1Fail(t *testing.T) {
	req := request.RequestLogin{"COORDINADOR", "pass"}
	pass1 := impl.PassNivel1{}
	var res = req.Validate(pass1)
	if res != true {
		t.Errorf("No hace merge la respuesta con la prueba unitaria")
	}
}
