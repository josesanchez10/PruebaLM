package com.project.project.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class TranslateRequest {
	private String text;
	private String origin;
	private String destination;
}
