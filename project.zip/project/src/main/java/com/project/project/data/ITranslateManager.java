package com.project.project.data;

public interface ITranslateManager <T> {
	/**
	 * Metodo que nos ayudara a identificar que tipo de encriptado debemos usar
	 * @param type
	 * @return
	 */
	ITranslate<T> TranslateManager(String type);
}
