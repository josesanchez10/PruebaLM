package com.project.project.data;

import org.springframework.context.ApplicationContext;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;

import com.project.project.model.TranslateResponse;

import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Component
@AllArgsConstructor
public class TranslateManagerImp implements ITranslateManager<TranslateResponse> {
	private ApplicationContext context;
	private TranslatorConfiguration implementationConfiguration;
	private final String DEFAULT_IMPLEMENTATION = "general";
	
	@Override
	@SuppressWarnings("unchecked")
	public ITranslate<TranslateResponse> TranslateManager(String type) {
		String implementation;
		try {
			implementation = implementationConfiguration.getImplementation().get(type);
			if((implementation = implementationConfiguration.getImplementation().get(type)) == null)
				implementation = implementationConfiguration.getImplementation().get(DEFAULT_IMPLEMENTATION);
			
			log.info("Response: {}", implementation);
			
			return (ITranslate<TranslateResponse>) context.getBean(implementation);
		} catch(RestClientException e) {
			log.error("Error identificando el traductor: {}", e);
			
			return null;
		}
	}
}
