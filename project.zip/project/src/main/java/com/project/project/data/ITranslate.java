package com.project.project.data;

public interface ITranslate<T> {
	
	/**
	 * Metodo para traducir de un formato X a Texto
	 * @param text
	 * @return
	 */
	T translateToText(String text);
	
	/**
	 * Metodo para traducir de texto a un Formato X
	 * @param text
	 * @return
	 */
	T translateToFormat(String text);
}
