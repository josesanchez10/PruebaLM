package com.project.project.data;

import org.springframework.stereotype.Component;

import com.project.project.model.TranslateResponse;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Component("TranslateBinaryImp")
public class TranslateBinaryImp implements ITranslate<TranslateResponse>{
	
	@Override
	public TranslateResponse translateToText(String text) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public TranslateResponse translateToFormat(String text) {
		// TODO Auto-generated method stub
		return null;
	}

}
