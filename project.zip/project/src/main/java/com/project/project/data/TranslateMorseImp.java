package com.project.project.data;

import org.springframework.stereotype.Component;

import com.project.project.model.TranslateResponse;

import lombok.AllArgsConstructor;

@AllArgsConstructor
@Component("TranslateMorseImp")
public class TranslateMorseImp implements ITranslate<TranslateResponse>{
	
	@Override
	public TranslateResponse translateToText(String text) {
		
		return null;
	}

	@Override
	public TranslateResponse translateToFormat(String text) {
		
		return null;
	}

}
