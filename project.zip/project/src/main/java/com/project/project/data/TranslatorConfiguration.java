package com.project.project.data;

import java.util.Map;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import lombok.Data;

@Data
@Component
@ConfigurationProperties(prefix = "service.configuration.traductor")
public class TranslatorConfiguration {
	private Map<String, String> implementation;
}
