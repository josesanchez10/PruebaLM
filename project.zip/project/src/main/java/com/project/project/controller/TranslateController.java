package com.project.project.controller;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.project.data.ITranslate;
import com.project.project.data.ITranslateManager;
import com.project.project.model.TranslateRequest;
import com.project.project.model.TranslateResponse;

import lombok.AllArgsConstructor;

@RestController
@AllArgsConstructor
public class TranslateController {

	private ITranslateManager<TranslateResponse> translate;
	
	@PostMapping("/translate")
    public TranslateResponse translate(@RequestBody TranslateRequest req){
		System.out.println(req);
        return selection(req);
    }
	
	private TranslateResponse selection(TranslateRequest req) {
		TranslateResponse response = new TranslateResponse("Traductor");
		
		//ITranslate<TranslateResponse> traductor = translate.TranslateManager(req.getDestination());
		return response;
	}
}
